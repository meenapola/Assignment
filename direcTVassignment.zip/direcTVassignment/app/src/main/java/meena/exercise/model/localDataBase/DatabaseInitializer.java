package meena.exercise.model.localDataBase;

import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;

import com.google.common.collect.Lists;

import java.util.List;
import java.util.Map;

import meena.exercise.model.data.Channel;
import meena.exercise.model.data.Program;


public class DatabaseInitializer {

    private static final String TAG = DatabaseInitializer.class.getName();

    public static void populateAsync(@NonNull final AppDatabase db) {
        PopulateDbAsync task = new PopulateDbAsync(db);
        task.execute();
    }

    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

        private final AppDatabase mDb;
        PopulateDbAsync(AppDatabase db) {
            mDb = db;
        }
        private static void populateWithTestData(AppDatabase db) {
           // Map<EPGChannel, List<EPGEvent>> getMockData() {
            Map<Channel, List<Program>> result =  MockedData.getMockData();
            List<Channel> channels = Lists.newArrayList();
             List<List<Program>> events = Lists.newArrayList();
            channels = Lists.newArrayList(result.keySet());
            events = Lists.newArrayList(result.values());
            Channel ch = new Channel(channels.get(0).getName(),channels.get(0).getChannelID(),channels.get(0).getImageURL());
            addChannel(db, ch);

            List<Channel> channelList = db.channelDao().getAllChannels();
            Log.d(DatabaseInitializer.TAG, "Rows Count:" + channelList.size());

        }

        private static Channel addChannel(final AppDatabase db, Channel channel) {
            db.channelDao().insertAll(channel);
            return channel;
        }

        @Override
        protected Void doInBackground(final Void... params) {
            populateWithTestData(mDb);
            return null;
        }

    }
}
