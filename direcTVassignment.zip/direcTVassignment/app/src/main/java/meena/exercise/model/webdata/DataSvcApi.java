package meena.exercise.model.webdata;


import java.util.List;

import meena.exercise.model.data.Program;
import meena.exercise.model.data.ScheduleRecording;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;



public interface DataSvcApi {

    public static final String ID_PARAMETER = "id";

    public static final String PID_PARAMETER = "pid";

    public static final String CHANNEL_NAME = "name";

    public static final String CHANNEL_NUMBER_PARAMETER = "channelNumber";

    // The path where we expect the ChannelSvc to live
    public static final String CHANNEL_SVC_PATH = "/channels";

    // The path where we expect the ProgramSvc to live
    public static final String PROGRAM_SVC_PATH = "/programs";
    
    // The path where we expect the ProgramSvc to live
    public static final String DATA_SVC_PATH = "/data";

    // The path where we expect the ScheduledRecordingSvc to live
    public static final String SCHEDULED_RECORDING_SVC_PATH = "/scheduledRecording";


    @GET("/channels/{name}/programs")
    Call<List<Program>> getProgramListByChannelName(@Path("name") String cName);


    @POST(SCHEDULED_RECORDING_SVC_PATH  + "/{id}" + "/{pid}")
    Call<ScheduleRecording> getProgramByChNamePgId(@Path("channelNumber") String id, @Path("programID") long pId);

    @DELETE(SCHEDULED_RECORDING_SVC_PATH +"/{id}")
    Call<Program> cancelSchedulrRecording(@Path("id") long id);


}
