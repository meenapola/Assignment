package meena.exercise.model.data;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;


@Entity(tableName = "programs",
  foreignKeys = @ForeignKey(entity = Channel.class,
        parentColumns = "id",
        childColumns = "id"))
public class Program {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "programid")
    private  String programID;

    @ColumnInfo(name = "id")
    public String channelId;

    @ColumnInfo(name = "start")
    private  long start;

    @ColumnInfo(name = "end")
    private  long end;

    @ColumnInfo(name = "name")
    private  String title;

    @ColumnInfo(name = "srecording")
    public boolean scheduledForRecording = false;

    @Embedded
    public ScheduleRecording srecording;

    public Program(String programID,long start, long end, String title) {
        this.programID = programID;
        this.start = start;
        this.end = end;
        this.title = title;
        this.scheduledForRecording = false;
    }

    public String getProgramID() {
        return programID;
    }

    public long getStart() {
        return start;
    }

    public long getEnd() {
        return end;
    }

    public String getTitle() {
        return title;
    }

    public void setStart(long start) {

      this.start = start;
    }

    public void setEnd(long end) {

        this.end = end;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setProgramID(String id) {

        this.programID = programID;
    }

    public boolean isCurrent() {
        long now = System.currentTimeMillis();
        return now >= start && now <= end;
    }

    public void setIsScheduleRecording() {
        if(scheduledForRecording) {
            scheduledForRecording = false;
        } else {
            scheduledForRecording = true;
        }
    }

    public boolean isScheduledForRecording(){
        return scheduledForRecording;
    }
    public boolean equals(Object obj)
    {
        return (this == obj);
    }
}
