package meena.exercise.epg.misc;


import java.util.ArrayList;
import java.util.Iterator;

import meena.exercise.epg.domain.EPGEvent;

/**
 * stores all the scheduled recordings and provides a function to check if there is a conflict
 */
public class RecordingsRepo {

    ArrayList<EPGEvent>  list;
    public RecordingsRepo() {
        list =  new ArrayList<EPGEvent>();
    }

    public void addEvent(EPGEvent event) {
        list.add(event);
    }

    public void removeEvent(EPGEvent event) {
        list.remove(event);
    }

    public boolean isThereAConflict(EPGEvent event) {
        long start = event.getStart();
        long end = event.getEnd();

        Iterator<EPGEvent> itr = list.iterator();
        while (itr.hasNext()) {
            EPGEvent element = (EPGEvent)itr.next();
            long curStart = element.getStart();
            long curEnd = element.getEnd();
            if((curStart > start && curStart < end) || (start > curStart && start < curEnd)){
                return true;
            } else if( (curEnd > start && curEnd < end) || (end > curStart && end < curEnd) ){
                return true;
            }
        }
        return false;
    }

}
