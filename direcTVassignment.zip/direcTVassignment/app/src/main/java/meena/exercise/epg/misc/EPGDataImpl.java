package meena.exercise.epg.misc;

import android.databinding.BaseObservable;
import android.databinding.Bindable;

import com.google.common.collect.Lists;

import java.util.List;
import java.util.Map;

import meena.exercise.epg.EPGData;
import meena.exercise.epg.domain.EPGChannel;
import meena.exercise.epg.domain.EPGEvent;


public class EPGDataImpl extends BaseObservable implements EPGData  {

    private List<EPGChannel> channels = Lists.newArrayList();

    @Bindable
    private List<List<EPGEvent>> events = Lists.newArrayList();

    public EPGDataImpl(Map<EPGChannel, List<EPGEvent>> data) {
        channels = Lists.newArrayList(data.keySet());
        events = Lists.newArrayList(data.values());
    }

    public EPGChannel getChannel(int position) {
        return channels.get(position);
    }


    public List<EPGEvent> getEvents(int channelPosition) {
       // notifyPropertyChanged(BR.events);
        return events.get(channelPosition);

    }


    public EPGEvent getEvent(int channelPosition, int programPosition) {
        return events.get(channelPosition).get(programPosition);
    }

    public int getChannelCount() {
        return channels.size();
    }


    public boolean hasData() {
        return !channels.isEmpty();
    }
}
