package meena.exercise.model.localDataBase;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import meena.exercise.model.data.Program;


@Dao
public interface ProgramDao {

    @Query("SELECT * FROM programs")
    public List<Program> getAllChannels();

    @Insert
    void insertAll(Program... program);

    @Delete
    void delete(Program program);

    @Query("SELECT * FROM programs WHERE id = :channel_id")
    List<Program> getProgramsForChannel(String channel_id);
}
