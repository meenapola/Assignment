package meena.exercise.model.data;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import com.google.common.base.Objects;


/**
 * A simple object to represent a scheduleRecording . *
 * **/

 @Entity(tableName = "srecording")
public class ScheduleRecording {

    @PrimaryKey
  @ColumnInfo(name = "sid")
 private long sRecordingID;

 private  String sRecordingName;
 private long sRecordingStartTime;
 private long sRecordingEndTime;
 private long sRecordingDuration;
 private boolean isScheduledForRecording;


 public  ScheduleRecording(String sRecordingName, long sRecordingStartTime, long sRecordingEndTime, long sRecordingDuration, boolean isScheduledForRecording) {

 this.sRecordingName = sRecordingName;
 this.sRecordingStartTime = sRecordingStartTime;
 this.sRecordingEndTime = sRecordingEndTime;
 this.sRecordingDuration = sRecordingDuration;
 this.isScheduledForRecording = isScheduledForRecording;
 }

 public long getSRecordingID() {
 return sRecordingID;
 }

 public String getSRecordingName() {
 return sRecordingName;
 }

 public long getSRecordingStartTime() {
 return sRecordingStartTime;
 }
 public long getSRecordingEndTime() {
 return sRecordingEndTime;
 }

 public long getSRecordingDuration() {
 return sRecordingDuration;
 }
 public boolean isScheduledForRecording() {
 return isScheduledForRecording;
 }

 public void setSRecordingID(long sRecordingID) {
 this.sRecordingID = sRecordingID;
 }

 public void setSRecordingName(String sRecordingName) {
 this.sRecordingName = sRecordingName;
 }

 public void setSRecordingStartTime(long sRecordingStartTime) {
 this.sRecordingStartTime = sRecordingStartTime;
 }

 public void setSRecordingEndTime(long sRecordingEndTime) {
 this.sRecordingEndTime = sRecordingEndTime;
 }

 public void setSRecordingDuration(long sRecordingID) {
 this.sRecordingDuration = sRecordingDuration;
 }

 public void setIsScheduledForRecording(boolean sRecordingID) {
 this.isScheduledForRecording = true;
 }

@Override
public int hashCode() {
        // Google Guava provides great utilities for hashing
        return Objects.hashCode(sRecordingID, sRecordingName, sRecordingStartTime,sRecordingEndTime,sRecordingDuration,isScheduledForRecording);
        }


        }
