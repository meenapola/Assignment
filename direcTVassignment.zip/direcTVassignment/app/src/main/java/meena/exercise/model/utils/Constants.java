package meena.exercise.model.utils;

/**
 * Class that contains all the Constants required in  client Application.
 */
public class Constants {
	
	/* * URL of the GotItWebService.  Please Read the Instructions in
     * README.md to set up the SERVER_URL.
     */
    public static final String SERVER_URL = "https://10.0.2.2:8443";
    	//	for emulator"http://10.0.2.2:8080";
    		// for real device "http://192.168.2.7:8080";
    		
    /**
     * Define a constant for 1 MB.
     */
    public static final long MEGA_BYTE = 1024 * 1024;

    /**
     * Maximum size of Video to be uploaded in MB.
     */
    public static final long MAX_SIZE_MEGA_BYTE = 50 * MEGA_BYTE;
    
    public static final String CLIENT_ID = "mobile";

}
