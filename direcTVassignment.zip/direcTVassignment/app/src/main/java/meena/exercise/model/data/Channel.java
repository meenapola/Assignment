package meena.exercise.model.data;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.common.base.Objects;


@Entity(tableName = "channel")
public class Channel {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    private  String channelID;

    @Nullable
    @ColumnInfo(name = "name")
    private  String name;

    @ColumnInfo(name = "imageurl")
    private  String imageURL;

    public Channel(String imageURL, String name, String channelID) {
        this.imageURL = imageURL;
        this.name = name;
        this.channelID = channelID;
    }

    public String getChannelID() {
        return channelID;
    }

    public String getName() {
        return name;
    }


    public String getImageURL() {
        return imageURL;
    }

    public void setChannelID(String id) {

        this.channelID = id;
    }
    public void setName(String name) {

        this.name = name;
    }
    public void setImageURL(String url) {

        this.imageURL = imageURL;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Channel task = (Channel) o;
        return Objects.equal(channelID, task.channelID) &&
                Objects.equal(name, task.name) &&
                Objects.equal(imageURL, task.imageURL);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(channelID, name, imageURL);
    }

    @Override
    public String toString() {
        return " title " + name;
    }
}
