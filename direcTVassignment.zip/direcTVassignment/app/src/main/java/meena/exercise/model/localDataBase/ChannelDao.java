package meena.exercise.model.localDataBase;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import meena.exercise.model.data.Channel;


@Dao
public interface ChannelDao {

    @Query("SELECT * FROM channel")
    public List<Channel> getAllChannels();

    @Insert
    void insertAll(Channel... channel);

    @Delete
    void delete(Channel channel);


}
