package meena.exercise;

import android.databinding.DataBindingUtil;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import meena.exercise.databinding.ActivityMainBinding;
import meena.exercise.epg.EPG;
import meena.exercise.epg.EPGClickListener;
import meena.exercise.epg.EPGData;
import meena.exercise.epg.domain.EPGChannel;
import meena.exercise.epg.domain.EPGEvent;
import meena.exercise.epg.misc.EPGDataImpl;
import meena.exercise.epg.misc.MockDataService;
import meena.exercise.epg.misc.RecordingsRepo;


public class MainActivity extends AppCompatActivity {

    private EPG epg;
    private RecordingsRepo recordingsRepo;

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        epg = (EPG)binding.epg;//(EPG) findViewById(R.id.epg);
        recordingsRepo = new RecordingsRepo();
        epg.setEPGClickListener(new EPGClickListener() {
            @Override
            public void onChannelClicked(int channelPosition, EPGChannel epgChannel) {
                Toast.makeText(MainActivity.this, epgChannel.getName() + " clicked", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onEventClicked(int channelPosition, int programPosition, EPGEvent epgEvent) {

                if(!epgEvent.isScheduledForRecording()) {
                    // check conflict and show a toast message
                    if( recordingsRepo.isThereAConflict(epgEvent) ){
                        Toast.makeText(MainActivity.this, epgEvent.getTitle() + " has conflict with another Scheduled Recoding", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    recordingsRepo.addEvent(epgEvent);
                    Toast.makeText(MainActivity.this, epgEvent.getTitle() + " Scheduled for recoding", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, epgEvent.getTitle() + " scheduled recording is cancelled", Toast.LENGTH_SHORT).show();
                    recordingsRepo.removeEvent(epgEvent);
                }
                epgEvent.scheduleRecording();
                epg.redraw();
            }

            @Override
            public void onResetButtonClicked() {
                epg.recalculateAndRedraw(true);
            }
        });

        // Do initial load of data.
        new AsyncLoadEPGData(epg).execute();
    }

    @Override
    protected void onDestroy() {
        if (epg != null) {
            epg.clearEPGImageCache();
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class AsyncLoadEPGData extends AsyncTask<Void, Void, EPGData> {

        EPG epg;

        public AsyncLoadEPGData(EPG epg) {
            this.epg = epg;
        }

        @Override
        protected EPGData doInBackground(Void... voids) {
            return new EPGDataImpl(MockDataService.getMockData());
        }

        @Override
        protected void onPostExecute(EPGData epgData) {
            //binding.setEpgData();
            binding.epg.setEPGData(epgData);
            //epg.setEPGData(epgData);
            epg.recalculateAndRedraw(false);
        }
    }
}
