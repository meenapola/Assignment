package meena.exercise.model.data;

import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Relation;

import java.util.List;

/**
 * Created by Ravi on 1/21/2018.
 */

public class ChannelAndAllPrograms {



    @Embedded
    public Channel channel;

    @Relation(parentColumn = "id", entityColumn = "channel_id", entity = Program.class)
    public List<Program> pgms;
}
